

#include "pch.h"
#include <iostream>
using namespace std;
int i;
int j;


void line()
{
	for (i = 1; i <= 39; i++)
		cout << "-";
	cout << endl;
}

int main()
{
	cout  << "   Nine-by-nine Multiplication Table    " << endl;
	line();
	cout << "  ";
	for (i = 1; i <= 9; i++)
		cout << "   " <<i; 
	cout << " "<<endl;
	line();
	for (i = 1; i <= 9; i++)
	{
		cout << " " << i;

		for (j = 1; j <= 9; j++)
		{
			if (j >= i)
			{
				if((i*j)/10==0)
				cout << "   " << i * j;
				else
				cout << "  " << i * j;
			}
			else
				cout << "    ";


		}
		cout << " " << endl;

	}
	line();




}

