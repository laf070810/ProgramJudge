
#include "pch.h"
#include<iostream>
using namespace std;

int k;//chucun
int i;//jishuqi
int sum;//zongshu


int main()
{
	for (i = 1; i <= 10; i++)
	{
		cin >> k;

		sum += k;


	}
	cout << sum << endl;

	

	return 0;


}
