

#include "pch.h"
#include <iostream>
using namespace std;

int sum;//zongshu
int k;//zancun

int main()
{
	while (1)
	{
		cin >> k;

		if (k == 0)
			break;
		else
			sum += k;

	}
	cout << sum << endl;


	return 0;

}
