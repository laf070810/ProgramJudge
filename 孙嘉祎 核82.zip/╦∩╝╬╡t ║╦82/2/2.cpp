

#include "pch.h"
#include <iostream>
#include<stdio.h>
using namespace std;
double corpus;//benjin
double rate;//lilv
double year;



int main()
{
	cin >> corpus >> rate >> year;
	for(int i=1;i<=year;i++)
	{
		corpus = corpus * (1 + rate/100);

	}
	printf("%.2f", corpus);


	return 0;



}
