

#include "pch.h"
#include <iostream>
using namespace std;

int i;
int p[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };//ping nian 
int r[13] = { 0,31,29,31,30,31,30,31,31,30,31,30,31 };//run nian
int w, c, d, y, m,ms,ys;//xingqi/shiji/riqi/nianfen/yue/nian/yue
int k;//jishuqi


void line()//fengefu
{
	for (i = 1; i <= 26; i++)
		cout << "-";
	cout << endl;
	

}
int date()//suanxingqi
{
	if (ys == 1582 && ms <= 10)//meiju 1582nain
	{
		if (ms == 10)
			w = 1;
		if (ms == 9)
			w = 6;
		if (ms == 8)
			w = 3;
		if (ms == 7)
			w = 7;
		if (ms == 6)
			w = 5;
		if (ms == 5)
			w = 2;
		if (ms == 4)
			w = 7;
		if (ms == 3)
			w = 4;
		if (ms == 2)
			w = 4;
		if (ms == 1)
			w = 1;
	}
	else
	{
		d = 1;
		c = ys / 100;//shiji-1
		y = ys % 100;
		if (ms == 1)
		{
			ys--;
			c = ys / 100;//shiji-1
			y = ys % 100;
			m = 13;
		}
		else
		{
			if (ms == 2)
			{
				ys--;
				c = ys / 100;//shiji-1
				y = ys % 100;
				m = 14;
			}
			else
				m = ms;
		}
		w = y + y / 4 + c / 4 - 2 * c + 26 * (m + 1) / 10 + d - 1;//gongshi
		w = w % 7;
	}

	return w;

}
void calendar()//dayinrili
{
	w = date();
	if (w < 7)
		w++;
	else
		w = 1;

	for (i = 1; i <= w - 1; i++)
	{
		cout << "    ";
	}
	k = w - 1;
	if (ys % 4 == 0)
	{
		for (i = 1; i <= r[ms]; i++)
		{
			if (i / 10 == 0)
				cout << " " << i;
			else
				cout << i;
			k++;
			if (k > 7)
			{
				k = k % 7;
			}
			if (k != 7)
				cout << "  ";
			else
				cout << endl;
		}
	}
	else
	{
		for (i = 1; i <= p[ms]; i++)
		{
			if (i / 10 == 0)
				cout << " " << i;
			else
				cout << i;
			k++;
			if (k > 7)
			{
				k = k % 7;
			}
			if (k != 7)
				cout << "  ";
			else
				cout << endl;
		}
	}
}
void calendar10()//dayinshiyuerili
{
	w = 1;
	if (w < 7)
		w++;
	else
		w = 1;

	for (i = 1; i <= w - 1; i++)
	{
		cout << "    ";
	}
	k = w - 1;
	
		for (i = 1; i <= 4; i++)
		{
			if (i / 10 == 0)
				cout << " " << i;
			else
				cout << i;
			k++;
			if (k > 7)
			{
				k = k % 7;
			}
			if (k != 7)
				cout << "  ";
			else
				cout << endl;
		}
		for (i = 15; i <= 31; i++)
		{
			if (i / 10 == 0)
				cout << " " << i;
			else
				cout << i;
			k++;
			if (k > 7)
			{
				k = k % 7;
			}
			if (k != 7)
				cout << "  ";
			else
				cout << endl;
		}

	
}
int main()
{
	
	cin >> ys >> ms;
	if(ms/10==0)
	cout << "Calendar "<<ys<<"-0"<<ms<<endl;
	else
	cout << "Calendar " << ys << "-" << ms << endl;
	line();
	cout << "Su  Mo  Tu  We  Th  Fr  Sa" << endl;
	line();
	if(ys==1582&&ms==10)
		calendar10();
	else
	calendar();
	if (k != 7)
		cout << endl;
	line();

	return 0;

	
}

