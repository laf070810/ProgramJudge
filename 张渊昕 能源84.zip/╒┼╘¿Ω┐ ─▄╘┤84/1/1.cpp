#include<stdio.h>
#include<stdlib.h>
int main()
{
	int a[10]={0},sum=0;
	for(int i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
		sum=sum+a[i];
	}
	printf("%d\n",sum);
	// system("pause");
	return 0;
}