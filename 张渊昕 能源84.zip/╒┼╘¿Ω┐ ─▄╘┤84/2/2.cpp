#include<stdio.h>
#include<stdlib.h>
int main()
{
	float m,n,k,sum=0;
	scanf("%f%f%f",&m,&k,&n);
	sum=sum+m;
	for(int i=1;i<=n;i++)
		sum=sum+k*sum/100;
	printf("%.2f\n",sum);
	system("pause");
	return 0;
}