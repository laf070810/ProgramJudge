#include<stdio.h>
#include<stdlib.h>
int main()
{
	int sum=0,i=0;
	while(1)
	{
		scanf("%d",&i);
		if(i!=0)
			sum=sum+i;
		else break;
	}
	printf("%d\n",sum);
	system("pause");
	return 0;
}