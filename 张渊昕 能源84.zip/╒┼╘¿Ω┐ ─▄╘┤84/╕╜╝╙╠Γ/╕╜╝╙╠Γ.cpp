#include<stdio.h>
#include<stdlib.h>

int IsRightYear(int n);
int IsBissextileYear(int n);
int Day(int n1,int n2);
int theBeginningDay();
int whatDay(int n);
int days(int n,int m);
int theFirstDay(int n,int m);
void Print(int n,int m);


int main()
{
	int n,m;
	scanf("%d%d",&n,&m);
	Print(n,m);
	system("pause");
	return 0;
}


//judge whether the input year is after 1582
int IsRightYear(int n)
{
	if(n>1582)return 1;
	else return -1;
}

//judge whether the input year is bissextile year
int IsBissextileYear(int n)
{
	if(n%100!=0)
	{
		if(n%4!=0)return 0;
		else return 1;
	}
	else if(n%400!=0)return 0;
	else return 1;
}

//calculate the number of days between two years
int Day(int n1,int n2)
{
	int sum=0;
	if(n1<n2)
		for(int i=n1;i<n2;i++)
			sum=sum+IsBissextileYear(i);
	else 
		for(int i=n2;i>n1;i--)
			sum=sum-IsBissextileYear(i);
	return (n2-n1)*365+sum;
}

//judge what day was Jan.1st,1583
int theBeginningDay()
{
	int a=Day(1583,2016);
	int b=a%7;
	b=12-b;
	return b%7;
}

//judge what day was Jan.1st in the input year
int whatDay(int n)
{
	int a=Day(1583,n);
	int b=a%7;
	b=b+theBeginningDay();
	return b%7;
}

//calculate how many days are there in a month
int days(int n,int m)
{
	if(m==1||m==3||m==5||m==7||m==8||m==10||m==12)return 31;
	else 
		if(m==2)
		{
			if(IsBissextileYear(n)==1)return 29;
			else return 28;
		}
		else return 30;
}

//judge what day is the first day of the input month
int theFirstDay(int n,int m)
{
	int a=whatDay(n),b=0;
	for(int i=1;i<m;i++)
		b=b+days(n,i);
	int c=b%7;
	c=c+a;
	c=c%7;
	return c;
}

//output
void Print(int n,int m)
{
	int c=theFirstDay(n,m);
	if(m<10)
	printf("Calendar %4d-0%d          \n",n,m);
	else printf("Calendar %4d-%d          \n",n,m);
	printf("--------------------------\n");
	printf("Su  Mo  Tu  We  Th  Fr  Sa\n");
	printf("--------------------------\n");
	for(int i=0;i<7;i++)
	{
		if(i<c)printf("    ");
		else printf("%2d  ",i-c+1);
	}
	printf("\n");
	for(int i=7-c+1,x=0;i<=days(n,m);i++)
	{
		printf("%2d  ",i);
		x=x+1;
		if(x%7==0)printf("\n");
	}
	printf("\n");
}
